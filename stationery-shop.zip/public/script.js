let cart = [];

fetch("/products")
.then(res => res.json())
.then(data => {
    const div = document.getElementById("products");

    data.forEach(p => {
        div.innerHTML += `
        <p>${p.name} - ₹${p.price}
        <button onclick="addToCart('${p.name}', ${p.price})">Add</button></p>`;
    });
});

function addToCart(name, price){
    cart.push({name, price});
    displayCart();
}

function displayCart(){
    const ul = document.getElementById("cart");
    ul.innerHTML = "";
    cart.forEach(c => {
        ul.innerHTML += `<li>${c.name} - ₹${c.price}</li>`;
    });
}

function pay(){
    window.location.href = "upi://pay?pa=9035689664@upi&pn=StationeryShop";
}