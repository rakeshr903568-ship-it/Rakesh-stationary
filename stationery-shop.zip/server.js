const express = require("express");
const fs = require("fs");
const app = express();

app.use(express.json());
app.use(express.static("public"));

let data = require("./data.json");

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    if (username === "admin" && password === "admin123") {
        res.json({ role: "admin" });
    } else {
        res.json({ role: "user" });
    }
});

app.get("/products", (req, res) => {
    res.json(data.products);
});

app.post("/add", (req, res) => {
    data.products.push(req.body);
    fs.writeFileSync("data.json", JSON.stringify(data));
    res.send("Added");
});

app.delete("/delete/:id", (req, res) => {
    data.products = data.products.filter(p => p.id != req.params.id);
    fs.writeFileSync("data.json", JSON.stringify(data));
    res.send("Deleted");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Running on " + PORT));
